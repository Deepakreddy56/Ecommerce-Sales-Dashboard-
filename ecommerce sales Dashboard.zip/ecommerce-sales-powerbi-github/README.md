# E-Commerce Sales & Profit Analysis Dashboard | Power BI

An interactive Power BI project for exploring e-commerce sales, profit, product categories, payment methods, and customer order geography. The repository includes the Power BI report file and the two CSV datasets used by the report.

## Project Overview

This dashboard helps users explore business performance across:

- **Sales and profit:** review total sales, total profit, and quantity sold.
- **Product performance:** compare categories and sub-categories.
- **Payment methods:** understand how customers pay for orders.
- **Geographic performance:** explore orders by state and city.
- **Order trends:** analyze order activity by date.

> The exact visuals and measures depend on the saved `.pbix` report. Open the report in Power BI Desktop to inspect or modify them.

## Files in This Repository

```text
.
├── README.md
├── data/
│   ├── Details.csv
│   └── Orders.csv
└── powerbi/
    └── Ecommerce_Sales_Dashboard.pbix
```

## Dataset

The project contains two CSV files:

### `data/Orders.csv`

| Column | Description |
|---|---|
| `Order ID` | Identifier for an order |
| `Order Date` | Date the order was placed (source format: `DD-MM-YYYY`) |
| `CustomerName` | Customer name in the supplied dataset |
| `State` | State associated with the order |
| `City` | City associated with the order |

### `data/Details.csv`

| Column | Description |
|---|---|
| `Order ID` | Order identifier used to connect to `Orders.csv` |
| `Amount` | Amount recorded for the order line |
| `Profit` | Profit recorded for the order line |
| `Quantity` | Quantity recorded for the order line |
| `Category` | Product category |
| `Sub-Category` | Product sub-category |
| `PaymentMode` | Payment method |

## Data Model

Use `Order ID` to connect the two tables in Power BI:

- `Orders[Order ID]` → `Details[Order ID]`
- Recommended relationship: **one-to-many** from `Orders` to `Details`, with single-direction filtering from `Orders` to `Details`.
- Set `Orders[Order Date]` to the **Date** data type. If Power BI does not parse it correctly, use the locale-aware date conversion for `DD-MM-YYYY`.
- Set `Amount` and `Profit` to numeric types and `Quantity` to a whole number.

The supplied files contain 500 unique order IDs in `Orders.csv` and 1,500 detail rows in `Details.csv`, with the order IDs matching across both files.

## How to Open the Dashboard

1. Download or clone this repository.
2. Open `powerbi/Ecommerce_Sales_Dashboard.pbix` using **Microsoft Power BI Desktop**.
3. If Power BI asks for data sources, point it to the CSV files in the `data/` folder. If the original report uses old local file paths, update them through **Transform data → Data source settings** or **Transform data**.
4. Select **Refresh** to reload the data.
5. Explore the report and use slicers/filters available in the dashboard.

## Tools Used

- Microsoft Power BI Desktop
- Power Query for data loading and transformation
- CSV datasets
- Power BI data modeling and visual analytics

## Potential Business Questions

- Which product categories contribute the most sales and profit?
- Which sub-categories perform best or need attention?
- Which payment methods are most frequently used?
- Which states and cities contribute the most orders or revenue?
- How do sales and profit change over time?

## Notes

- The included data covers orders dated in **2018**.
- Confirm the source and usage permissions for the supplied datasets before redistributing them publicly.
- If you publish a Power BI Service link, add it here only after checking that it points to this e-commerce report and that intended viewers have access.

## Author

**Deepak Reddy**  
Power BI | Data Analytics | Data Visualization
