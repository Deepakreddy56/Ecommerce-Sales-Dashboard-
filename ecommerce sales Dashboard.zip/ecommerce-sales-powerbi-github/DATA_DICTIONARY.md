# Data Dictionary

## Orders.csv

- `Order ID` — Order key; relates to `Details.csv`.
- `Order Date` — Order date, supplied in `DD-MM-YYYY` format.
- `CustomerName` — Customer name from the source dataset.
- `State` — State associated with the order.
- `City` — City associated with the order.

## Details.csv

- `Order ID` — Order key; multiple detail rows may exist per order.
- `Amount` — Amount for the detail row.
- `Profit` — Profit for the detail row.
- `Quantity` — Quantity for the detail row.
- `Category` — Product category.
- `Sub-Category` — More specific product group.
- `PaymentMode` — Payment method recorded for the detail row.
